<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Tai</title>
</head>
<body>
  <h1>Ayo Ngoding</h1>
  <p>Belajar Bahasa Pemrograman Lanjutan</p>
  <h1>Santri Kelas XIII Yayasan Dar El Ilmi</h1>
</body>
</html><?php /**PATH C:\Users\USER\taufikz\barang\resources\views/barang.blade.php ENDPATH**/ ?>