<div class="row ">
    <div class="col-8 col-sm-2">
        {{$header}}
    </div>
    :
    <div class="col-12 col-sm-6">
        {{$badan}}
    </div>
</div>