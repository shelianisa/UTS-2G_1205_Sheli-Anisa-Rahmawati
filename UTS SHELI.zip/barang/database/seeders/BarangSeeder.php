<?php

namespace Database\Seeders;

use App\Models\barang as ModelsBarang;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BarangSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       ModelsBarang::insert(
            [
                [
                    'namaBarang' => 'Baju Kemeja polos Wanita',
                    'fotoBarang' => 'kemeja1.jpg',
                    'harga' => '100000',
                    'stok' => '200',
                    'ukuran' => 'm, l, xl, xxl',
                    'reviewBarang' => '100% Katun, bahan eksklusif yang halus dan terasa nyaman di kulit. 
                    Bahannya yang licin juga membuat kemeja tidak mudah terkena noda membandel. Pas dan terlihat 
                    keren untuk Anda yang berukuran umum.  terasa ringan di badan dan terasa adem 
                    digunakan.',
                ],
                [
                    'namaBarang' => 'Celana Jeans Wanita',
                    'fotoBarang' => 'gambar2.jpg',
                    'harga' => '150000',
                    'stok' => '200',
                    'ukuran' => 'm, l, xl, xxl',
                    'reviewBarang' => 'Bagi pecinta celana pendek / Pnjang  wajib banget nih kalian punya produk ini
                    Karena bukan hanya tampilan nya yang bagus, kami juga sangat detail dan hati-hati dalam pengerjaan nya
                    Jahitan nya sangat rapih',
                ],
                [
                    'namaBarang' => 'Tas Wanita',
                    'fotoBarang' => 'tas2.jpg',
                    'harga' => '80000',
                    'stok' => '200',
                    'ukuran' => 'm, l, xl, xxl',
                    'reviewBarang' => 'Bagi pecinta tas, kami juga sangat detail dan hati-hati dalam pengerjaan nya
                    Jahitan nya sangat rapih, dan kami juga memilih kain yang terbaik
                    Produk ini terbuat dari kain Fleece ya ka',
                ],
                [
                    'namaBarang' => 'Kaos pendek cowok',
                    'fotoBarang' => 'gambar4.jpg',
                    'harga' => '50000',
                    'stok' => '100',
                    'ukuran' => 'm, l, xl, xxl',
                    'reviewBarang' => 'Kain rayon dan nyaman dipakai .Cocok untuk santai bepergian atau liburan
                    jahitan rapi dan tersedia berbagai warna  terasa ringan di badan dan terasa adem 
                    digunakan. ',
                ],
            ]
        );
    }
}
